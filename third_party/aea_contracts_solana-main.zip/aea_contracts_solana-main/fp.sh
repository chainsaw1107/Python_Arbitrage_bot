#!/bin/bash

while true; do
    cd packages/vybe
    aea fingerprint contract dassy23/jupitar_swap:0.1.0
    sleep 5
done
