# aea_contracts_solana

This repository contains contracts for the AEA framework on the Solana blockchain.



